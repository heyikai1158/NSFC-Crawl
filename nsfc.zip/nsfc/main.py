from Crypto.Cipher import DES
import base64
import json
import requests


# 国家自然科学基金大数据知识管理平台
# 共计可获取102页(实测得知)

def get_encode_data(page_num):
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "Authorization": "Bearer undefined",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Content-Length": "563",
        "Content-Type": "application/json;charset=UTF-8",
        "Host": "kd.nsfc.gov.cn",
        "Origin": "https://kd.nsfc.gov.cn",
        "Pragma": "no-cache",
        "Referer": "https://kd.nsfc.gov.cn/resultInit",
        "Sec-Ch-Ua": '"Microsoft Edge";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0"
    }
    data = {
        "authors": "",
        "baseSearchSign": "",
        "fuzzyKeyword": "",
        "grantCode": "",
        "hasFullText": False,
        "issuedBy": "",
        "issuedByScreening": "",
        "journalName": "",
        "journalNameScreening": "",
        "keywords": "",
        "keywordsScreening": "",
        "length": 10,
        "orderBy": "paperVisits",
        "orderType": "desc",
        "orgName": "",
        "patentNo": "",
        "patentType": "",
        "patentTypeScreening": "",
        "prjZhTitle": "",
        "proceedingName": "",
        "proceedingNameScreening": "",
        "productType": "",
        "productTypeScreening": "",
        "publishYear": "",
        "publishYearScreening": "",
        "publisher": "",
        "publisherScreening": "",
        "startPoint": page_num,
        "subjectCode1": "",
        "zhTitle": ""
    }
    # 科研成果API
    url = "https://kd.nsfc.gov.cn/api/baseQuery/search"
    response = requests.post(url=url, headers=headers, data=json.dumps(data))
    return response.text


def decrypt_des(encrypted_text, page_num):
    # 使用 Base64 解码密文
    encrypted_data = base64.b64decode(encrypted_text)

    # 创建 DES 解密器，使用 ECB 模式
    cipher = DES.new(b'SecretIs', DES.MODE_ECB)

    # 解密数据
    decrypted_data = cipher.decrypt(encrypted_data)

    # 移除填充，手动处理 PKCS7 填充
    unpadded_data = unpad_pkcs7(decrypted_data)

    decrypted_text = unpadded_data.decode('utf-8')

    # 将解密后的结果转换为字符串，并解析为 JSON 对象
    decrypted_json = json.loads(decrypted_text)

    save_data_with_json(decrypted_json, str(page_num + 1))

    return decrypted_json


def save_data_with_json(data, page_num):
    # 读取传递的json数据并保存为json文件
    with open('page-' + page_num + '.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)


def unpad_pkcs7(data):
    # 计算要移除的填充字节数
    pad_length = data[-1]
    # 移除填充
    unpadded_data = data[:-pad_length]
    return unpadded_data


if __name__ == '__main__':
    print("请输入总页数:")
    page_num = input()
    for i in range(0, int(page_num)):
        print("正在爬取第" + str(i + 1) + "页数据...")
        decrypted_data = decrypt_des(get_encode_data(i), i)
        print(decrypted_data)
